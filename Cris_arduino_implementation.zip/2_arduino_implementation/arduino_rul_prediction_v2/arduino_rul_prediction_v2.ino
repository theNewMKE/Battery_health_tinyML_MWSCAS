// Description:
// receive 20*8 datapoint from python program running on PC
// use that as input into tynyML model, whcih makes prediction
// send prediction back to PC
//
// this Arduino sketch is developed starting from the Arduino examples
// "hello_world" and "micro_speech" from the tinyML book of Pete Warden.
// the latest version of these examples is available here:
// https://github.com/tensorflow/tflite-micro-arduino-examples/tree/main
// the (development, training, etc.) files are here:
// https://github.com/tensorflow/tflite-micro/tree/main/tensorflow/lite/micro/examples

#include <TensorFlowLite.h>
#include "main_functions.h"
#include "model.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_log.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/schema/schema_generated.h"


// (1) Declare Variables
// Globals, used for compatibility with Arduino-style sketches.
// This is an "unnanmed namespace" - allows us to create identifiers
// that are unique wihin a file; they are also called "anonymous namespaces";
// these identifiers are known only within this file;
namespace {
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;
int inference_count = 0;

// Create an area of memory to use for input, output, and intermediate arrays.
// The size of this will depend on the model you're using, and may need to be
// determined by experimentation.
constexpr int kTensorArenaSize = 80 * 1024;
alignas(16) uint8_t tensor_arena[kTensorArenaSize];
int8_t* model_input_buffer = nullptr;
} // namespace


#define BUFFER_SIZE 160 // should be exactly the same as "kFeatureElementCount"
float data_buffer[BUFFER_SIZE];
bool data_received_flag = false;
// a fixed 160 datapoint buffer; used for local debug;
float data_buffer_fixed[] = {0.85769287, 0.91666667, 0.70801953, 0.15812045, 0.05682766, 0.15136703,  0.05509788, 0.27653167, 0.90251432, 0.05562347, 0.72383908, 0.65864495, 0.2040728,  0.67086314, 0.2138099,  0.2569055,  0.66249458, 0.45141513, 0.90088181, 0.7110021,  0.04635209, 0.7217374,  0.04984498, 0.22107996, 0.13310408, 1.,         0.78204594, 0.23074787, 0.,         0.21222381, 0.,         0.70404984, 0.17764025, 1.,         0.93062862, 0.58160558, 0.,         0.56453664, 0.,         0.54257529, 0.49988083, 0.5, 0.55323014, 0.4087375,  0.34127499, 0.40996662, 0.34037559, 0.27455867, 0.71061486, 0.,         0.64553609, 0.71566087, 0.3525231,  0.72646638, 0.36442555, 0.18442368, 0.19252182, 1.,         0.784733,   0.21223621, 0.,         0.19578763, 0.,         0.48535826, 0.00955669, 0.33348151, 0.24603565, 0.99851907, 0.97305398, 0.99818789, 0.98198246, 0.57455867, 0.99750436, 0.33348151, 0.60031034, 0.59940763, 0.46327369, 0.61478302, 0.48357693, 0.11557632, 0.53459876, 0.33348151, 0.46599553, 0.74639023, 0.725163,   0.75593705, 0.74782532, 0.3549325,  0.12364497, 0., 0.49294176, 0.91484635, 0.7227836,  0.91654745, 0.73476836, 0.47715472, 0.99523324, 0.33353708, 0.65923627, 0.58867086, 0.36917895, 0.60209824, 0.39189476, 0.21079958, 0.00360049, 1.,         0.78272717, 0.27249167, 0.,         0.25116834, 0.,         0.41214953, 0.54513806, 1., 0.76535594, 0.07361471, 0.,         0.06698458, 0.,         0.33509865, 0.81480571, 0.74998148, 0.63721001, 0.24302727, 0.1663422,  0.23977905, 0.16305253, 0.2290758,  0.58123993, 0.58337038, 0.58331756, 0.34656917, 0.27734001, 0.34721825, 0.27203472, 0.28483904, 0.72923879, 0.75, 0.62245014, 0.24737751, 0.17397485, 0.24393578, 0.17010364, 0.17237799, 0.45595458, 1.,         0.90425009, 0.41537085, 0.,         0.40255921, 0.,         0.2384216,  0.19286309, 1.,         0.87109715, 0.43382081, 0.,         0.41383723, 0.,         0.59252336};

///////////////////////////////////////////////////////////////////////////////
//
// setup
//
///////////////////////////////////////////////////////////////////////////////

void setup() 
{
  // we will use Serial to talk to Python program on PC;
  // to receive datpoints of 20*8 float numbers and to send back prediction;
  Serial.begin(9600);
  while(!Serial);

  // init;
  tflite::InitializeTarget();

  // (2) Load Model
  // Map the model into a usable data structure. This doesn't involve any
  // copying or parsing, it's a very lightweight operation.
  model = tflite::GetModel(g_model);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    MicroPrintf(
        "Model provided is schema version %d not equal "
        "to supported version %d.",
        model->version(), TFLITE_SCHEMA_VERSION);
    return;
  }

  // (3) Resolve Operators
  // This pulls in all the operation implementations (Ops) we need.
  static tflite::AllOpsResolver resolver;

  // (4) Initialize Interpreter
  // Build an interpreter to run the model with.
  static tflite::MicroInterpreter static_interpreter(
    model, resolver, tensor_arena, kTensorArenaSize);
  interpreter = &static_interpreter;
  // TODO: look more into:
  // https://www.tensorflow.org/api_docs/python/tf/lite/Interpreter
  // https://www.tensorflow.org/lite/api_docs/java/org/tensorflow/lite/Interpreter
  // https://groups.google.com/a/tensorflow.org/g/micro/c/w38Q81rOR-w
  // https://coral.ai/docs/reference/micro/tensorflow/#tflm-interpreter

  // (5) Allocate Arena
  // Allocate memory from the tensor_arena for the model's tensors.
  TfLiteStatus allocate_status = interpreter->AllocateTensors();
  if (allocate_status != kTfLiteOk) {
    MicroPrintf("AllocateTensors() failed");
    return;
  }

  // (6) Define Model Inputs
  // Obtain pointers to the model's input and output tensors.
  // Get information about the memory area to use for the model's input.
  input = interpreter->input(0);
  if ((input->dims->size != 3)  
      || (input->dims->data[0] != 1) 
      || (input->dims->data[1] != 20) 
      || (input->dims->data[2] != 8)
      || (input->type != kTfLiteInt8)
      ) {
    MicroPrintf("Bad input tensor parameters in model");
    return;
  }
  // TODO: read more at:
  // https://www.tensorflow.org/lite/api_docs/c/union/tf-lite-ptr-union#union_tf_lite_ptr_union
  model_input_buffer = input->data.int8;
  output = interpreter->output(0);

  // (7) Set-up Main Loop
  // Keep track of how many inferences we have performed.
  inference_count = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// loop
//
///////////////////////////////////////////////////////////////////////////////

void loop() 
{
  int8_t x_quantized = 0;
  int8_t y_quantized = 0;
  float y_pred = 0.0;


  // (1) Input Data
  // here, we receive 20*8 float numbers from Python program runing on PC;
  float received_float = 0.0;
  int received_count = 0;
  data_received_flag = false;
  while (Serial.available() && received_count < BUFFER_SIZE) {
    data_received_flag = true;
    received_float = Serial.parseFloat();
    // store the byte to data_buffer array
    data_buffer[received_count] = received_float;
    received_count++;
  }


  // if we received a datapoint with exactly 20*8=160 values, then
  // we pass that to the model to make a prediction;
  if (data_received_flag == true) {

    // this will be used inside Python program 
    Serial.print(received_count);
    Serial.print("\r\n"); // "\r\n"

    if (received_count == BUFFER_SIZE) {
      // for debug purposes only:
      //Serial.println("Received " + String(received_count) + " numbers:");
      //for (int j=0; j<BUFFER_SIZE; j++) {
      //  Serial.print(data_buffer[j]);
      //  if (j < BUFFER_SIZE-1) { Serial.print(" "); }
      //}
      //Serial.print("\r\n");
      //delay(100);

      // to calculate exe time of inference, we record here
      // start time of inference
      long int t1_start = millis();

      // Copy feature buffer to input tensor
      // this is similar to the "micro_speech" example;
      for (int i = 0; i < BUFFER_SIZE; i++) {
        // take all 160 values from data_buffer and place into model_input_buffer; 
        // (2) Pre-Process
        // but, first Quantize the input from floating-point to integer
        x_quantized = data_buffer[i] / input->params.scale + input->params.zero_point;
        model_input_buffer[i] = x_quantized;
      }


      // (3) Use Model to Make Inference
      // Run inference, and report any error
      TfLiteStatus invoke_status = interpreter->Invoke();
      if (invoke_status != kTfLiteOk) {
        MicroPrintf("Invoke failed");
        return;
      }


      // (4) Post-Process
      // this is similar to "hello_world" example from tinyML book;
      // just get the predicted output; it is only one value;
      // Obtain the quantized output from model's output tensor
      y_quantized = output->data.int8[0];
      // Dequantize the output from integer to floating-point
      y_pred = (y_quantized - output->params.zero_point) * output->params.scale;

      // end time of inference
      long int t2_end = millis();


      // (5) Action 
      // in the original "hello_world" example, we used a HandleOutput() 
      // defined inside arduino_output_handler.cpp
      // here, we simply send the result back to Python program running on PC;
      //Serial.print("Inference time: ");
      //Serial.print(t2_end - t1_start);
      //Serial.print("\r\n"); // "\r\n"

      //Serial.print("Prediction #");
      //Serial.print(inference_count);
      //Serial.print(" is: ");
      //Serial.print("\r\n"); // "\r\n"

      Serial.print(y_pred);
      Serial.print("\r\n"); // "\r\n"
      
      // Increment the inference_counter;
      inference_count += 1;
      if (inference_count >= 10000) inference_count = 0;
    } else { 
      // ERROR: case when received_count != BUFFER_SIZE
    } // received_count == BUFFER_SIZE
  } // data_received_flag == true
  delay(100);
  
}
